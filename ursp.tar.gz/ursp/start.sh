#!/bin/bash
./ttyd -p 8022 -W bash
