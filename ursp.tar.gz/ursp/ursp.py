from csclient import EventingCSClient
import time

cp = EventingCSClient('URSP')

def parse_route_selection_descriptors(descriptors):
    '''
    Example descriptors:
    URSP_PROFILE_1 0,3,0,0|"10.31.57.102.255.255.255.255"||||||,0|"10.32.106.4.255.255.255.255"|||5006|||
    URSP_PROFILE_2 1,3,0,0|"8.8.8.8.255.255.255.255"||||||
    URSP_PROFILE_3 2,3,0,0|"13.107.64.0.255.255.192.0"||||||,0|"52.112.0.0.255.252.0.0"||||||,0|"52.122.0.0.255.254.0.0"||||||,0||"2603:1063::/38"|||||
    URSP_PROFILE_4 3,3,0,0|||||252:136|
    '''
    json_routes = []
    lines = descriptors.split('\n') # split by newline
    for line in lines:
        try:
            fields = line.split(' ')[1].split(',')
            pdn = int(fields[0]) # first field is pdn. ignore if not int.
            policies = fields[3:] # polices start from 3rd field
            for policy in policies:
                if ':' not in policy:  # IPv4
                    dest_ip = '.'.join(policy.split('"')[1].split('.')[0:4])
                    netmask = '.'.join(policy.split('"')[1].split('.')[4:])
                    port = policy.split('|')[4]
                    json_routes.append({
                        'pdn': pdn,
                        'dest_ip': dest_ip,
                        'netmask': netmask,
                        'port': port
                    })
        except ValueError:
            pass
    return json_routes

def parse_nssais(line):
    ''' Parse URSP_PROFILE_EX_ line to get APN, SST, and SD
    Example:
    URSP_PROFILE_EX_1: 5,0,"telstra.wap_EMBB000378",-1,0
    URSP_PROFILE_EX_2: 5,0,"telstra.testapp1_EMBB0003E8",-1,1
    URSP_PROFILE_EX_3: 5,0,"telstra.wap_EMBB000378",-1,2
    URSP_PROFILE_EX_4: 5,0,"telstra.internet",1,-1
    '''
    fields = line.split(',')
    apn = fields[2].split('_')[0]
    sst = fields[2].split('_')[1][:-6]
    sd = fields[2].split('_')[1][-6:].lstrip('0')
    return {
        'apn': apn,
        'sst': sst,
        'sd': sd
        }

def at_command(command):
    response = ''
    retries = 0
    while len(response) < 100:
        response = ct.exec(f'atterm {iface} -c {command}')
        if retries > 5:
            break
        retries += 1
        time.sleep(.1)
    return response

modem = cp.get('status/wan/primary_device')
iface = cp.get(f'status/wan/devices/{modem}/info/iface')

response = at_command(f'AT+QURSPQRYEX?')
routes = parse_route_selection_descriptors(response)
cp.log(f'routes: {routes}')

pdns = list(set([policy['pdn'] for policy in routes]))
for pdn in pdns:
    response = at_command(f'AT+QURSPQRYEX={pdn},0')
    nssai = parse_nssais(response)
    cp.log(f'nssai: {nssai}')

