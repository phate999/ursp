from csterm import CSTerm
from csclient import EventingCSClient
import time

cp = EventingCSClient('URSP')
ct = CSTerm(cp)

def parse_ursp(response):
    json_policies = []
    lines = response.split('\n') # split by newline
    for line in lines:
        line = line.replace('+QURSPQRYEX: ', '')  # Remove the prefix
        fields = line.split(',') # split by comma
        try:
            pdn = int(fields[0]) # first field is pdn. ignore if not int.
            policies = fields[3:] # polices start from 3rd field
            for policy in policies:
                if ':' not in policy:  # IPv4
                    dest_ip = '.'.join(policy.split('"')[1].split('.')[0:4])
                    netmask = '.'.join(policy.split('"')[1].split('.')[4:])
                    port = policy.split('|')[4]
                    json_policies.append({
                        'pdn': pdn,
                        'dest_ip': dest_ip,
                        'netmask': netmask,
                        'port': port
                    })
        except ValueError:
            pass
    return json_policies


# Get first connected modem iface
wan_devs = cp.get('status/wan/devices')
modems = [dev for dev in wan_devs if dev.startswith('mdm')]
for modem in modems:
        if cp.get(f'status/wan/devices/{modem}/status/connection_state') == 'connected':
            iface = cp.get(f'status/wan/devices/{modem}/info/iface')
            break

# Get URSP data
response = ''
retries = 0
while len(response) < 100:
    response = ct.exec(f'atterm {iface} -c AT+QURSPQRYEX?')
    if retries > 5:
        break
    retries += 1
    time.sleep(.1)

# Example response
# response = '+QURSPQRYEX: 0,3,0,0|"10.31.57.102.255.255.255.255"||||||,1|"10.32.106.4.255.255.255.255"|||5006|||\n+QURSPQRYEX: 1,3,0,0|"8.8.8.8.255.255.255.255"||||||\n+QURSPQRYEX: 2,3,0,0|"13.107.64.0.255.255.192.0"||||||,1|"52.112.0.0.255.252.0.0"||||||,2|"52.122.0.0.255.254.0.0"||||||,3||"2603:1063::/38"|||||\n+QURSPQRYEX: 3,3,0,0|||||136:252|\nOK'

policies = parse_ursp(response)
pdns = list(set([policy['pdn'] for policy in policies]))

# Log URSP data
cp.log(json.dumps(policies, indent=2))
cp.log(dnn_queries)

# Get DNN data
for pdn in pdns:
    response = ''
    retries = 0
    while len(response) < 100:
        response = ct.exec(f'atterm {iface} -c AT+QURSPQRYEX={pdn},0')
        if retries > 5:
            break
        retries += 1
        time.sleep(.1)
    dnn = response.split('"')[1]
    cp.log(f'PDN: {pdn}, DNN: {dnn}')


